
/**
 * Revised version of general Actor subclass for use in our games
 */
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Polygon;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Intersector.MinimumTranslationVector;
import java.util.ArrayList;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.utils.viewport.Viewport;


public class BaseActor extends Actor
{
   //properties to support Animation
   private Animation<TextureRegion> animation;
   private float elapsedTime;
   private boolean animationPaused; 
   
   //velocity vector
   private Vector2 velocityVec;
   
   //acceleration vector
   private Vector2 accelerationVec;
   private float acceleration; 
   
   private float maxSpeed;      //maximum speed of actor
   private float deceleration;  //amount of deceleration
   
   private Polygon boundaryPolygon;  //bounding polygon for collisions
   
   private static Rectangle worldBounds;    //the borders of the game world
   
   //create BaseActor and set its position and add to specified stage
   public BaseActor (float x, float y, Stage s) {
       super();     //invoke super class constructor
       
       //initialize our new properties
       animation = null;
       elapsedTime = 0;
       animationPaused = false;
       
       //initialize our velocity vector to (0, 0)
       velocityVec = new Vector2(0, 0);
       
       //initialize our acceleration properties
       accelerationVec = new Vector2(0, 0);
       acceleration = 0;
       
       maxSpeed = 1000; // default values
       deceleration = 0;
       
       //perform additional initialization
       setPosition(x,y);
       s.addActor(this);
   }
    
   //utility methods for our Animation support
   
   //setAnimation - makes the passed Animation object the Animation for our
   //       actor; uses size of first frame to set size of our actor
   public void setAnimation(Animation<TextureRegion> anim) {
       
       animation = anim;    //set our animation
       
       //get the first frame to figure out size of our actor
       TextureRegion tr = animation.getKeyFrame(0);     // get the first frame
       float w = tr.getRegionWidth();       //get width and height
       float h = tr.getRegionHeight();
       
       setSize(w, h);       // set size
       setOrigin(w/2, h/2); // set origin point to center of image
       
       //use a rectangle as bounding polygon by default
       if (boundaryPolygon == null) 
           setBoundaryRectangle();
          
    }
    
    public void setAnimationPaused(boolean pause) {
        animationPaused = pause;
    }
    
    //act() - override to automatically update the elapsed time based on dt
    public void act(float dt) {
        super.act(dt);      // invoke super class act() method
        
        if (!animationPaused)       // if animation is not paused, increment
            elapsedTime += dt;      // elapsed time by dt
        
    }
    
    //draw() - override to determine the correct animation frame to draw
    //          and draw the image
    public void draw(Batch batch, float parentAlpha) {
        
        super.draw(batch, parentAlpha);     // invoke super class draw() method
        
        //apply color tint effect
        Color c = getColor();
        batch.setColor(c.r, c.g, c.b, c.a);
        
        //if animation needs to be drawn, draw the correct frame
        if (animation != null && isVisible())
            batch.draw(animation.getKeyFrame(elapsedTime), getX(), getY(),
                getOriginX(), getOriginY(), getWidth(), getHeight(),
                getScaleX(), getScaleY(), getRotation());
    }
    
    //loadAnimationFromFiles() -- loads animation frames from separate files
    //  and returns the Animation object
    public Animation<TextureRegion> loadAnimationFromFiles (String[] fileNames,
                    float frameDuration, boolean loop) {
                        
        //figure out the number of frames
        int fileCount = fileNames.length;
        Array<TextureRegion> textureArray = new Array<TextureRegion>();
        
        //use for loop to load each frame
        for (int n = 0; n < fileCount; n++) {
            //get the file name
            String fileName = fileNames[n];
            
            //create a Texture from the file
            Texture texture = new Texture(Gdx.files.internal(fileName));
            
            //set the filter
            texture.setFilter(TextureFilter.Linear, TextureFilter.Linear);
            
            //add to our TextureRegion array
            textureArray.add(new TextureRegion(texture));
        }
        
        //create our Animation object from our loaded frames
        Animation<TextureRegion> anim = new Animation<TextureRegion>
                                            (frameDuration, textureArray);
        
        //set loop or not
        if (loop)
            anim.setPlayMode(Animation.PlayMode.LOOP);
        else
            anim.setPlayMode(Animation.PlayMode.NORMAL);
        
        //set it as animation if needed
        if (animation == null)
            setAnimation(anim);
        
        //return the animation
        return anim;
    }
    
    //loadAnimationFromSheet() -- loads frames from a single spritesheet
    public Animation<TextureRegion> loadAnimationFromSheet(String fileName,
                int rows, int cols, float frameDuration, boolean loop) {
        //load sprite sheet
        Texture texture = new Texture(Gdx.files.internal(fileName), true);
        texture.setFilter(TextureFilter.Linear, TextureFilter.Linear);
        
        //calculate size of sub-image
        int frameWidth = texture.getWidth() / cols;
        int frameHeight = texture.getHeight() / rows;
        
        //call split to get the individual frames in a 2-d array
        TextureRegion[][] temp = TextureRegion.split(texture, 
                                            frameWidth, frameHeight);
        
        //initialize our textureregion array
        Array<TextureRegion> textureArray = new Array<TextureRegion>();
        
        //use a nested for loop to pull each frame into a 1-d array of TextureRegion
        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                textureArray.add(temp[r][c]);
                
        //Create Animation
        Animation<TextureRegion> anim = new Animation<TextureRegion>(frameDuration,
                                                textureArray);
              
        //Looping?
        if (loop)
            anim.setPlayMode(Animation.PlayMode.LOOP);
        else
            anim.setPlayMode(Animation.PlayMode.NORMAL);
        
        //set as animation if needed
        if (animation == null)
            setAnimation(anim);
        
        //return animation
        return anim;        
    }
        
    //loadTexture() - used for still images; treat as an animation of 1 frame and 
    //    use the loadAnimationFromFiles() method, feeding it
    //    an array of 1 file name
    public Animation<TextureRegion> loadTexture(String fileName) {
        //create an array of our 1 file name
        String[] fileNames = new String[1];
        fileNames[0] = fileName;
        
       
        //use the loadAnimationFromFiles() method
        //  since image is static, have it constantly loop that 1 frame
        return loadAnimationFromFiles(fileNames, 1, true);
        
    }
    
    //isAnimationFinished() - tells us if the BaseActor's animation is finished
    public boolean isAnimationFinished() {
        return animation.isAnimationFinished(elapsedTime);
    }
    
    // Velocity utility methods
    
    //setspeed() - sets the speed.  Note that when velocity is <0, 0> angle 
    //    is undefined, so we assume angle is 0
    public void setSpeed(float speed) {
        //if length is zero, assume angle is zero degrees
        if (velocityVec.len() == 0)
            velocityVec.set(speed, 0);
        else
            velocityVec.setLength(speed);
    }
    
    //getSpeed() - get the speed
    public float getSpeed() {
        return velocityVec.len();
    }
    
    //setMotionAngle() - set the angle object is moving at
    public void setMotionAngle(float angle) {
        velocityVec.setAngle(angle);
    }
    
    //getMotionAngle() - get the current angle of motion
    public float getMotionAngle() {
        return velocityVec.angle();
    }
    
    //isMoving() - is the actor moving?
    public boolean isMoving() {
        return (getSpeed() > 0);
    }
    
    //Acceleration utility methods
    
    //setAcceleration() - 
    public void setAcceleration(float acc) {
        acceleration = acc;
    }
    
    //accelerateAtAngle(float angle) -- accelerate at given angle
    public void accelerateAtAngle(float angle) {
        accelerationVec.add(new Vector2 (acceleration, 0).setAngle(angle));
    }
    
    //accelerateForward() - accelerate in direction actor was moving
    public void accelerateForward() {
        accelerateAtAngle(getRotation());
    }
    
    //setMaxSpeed() - set a max speed to limit movement speed
    public void setMaxSpeed(float ms) {
        maxSpeed = ms;
    }
    
    //setDeceleration() - set amount of deceleration
    public void setDeceleration(float dec) {
        deceleration = dec;
    }
    
    //applyPhysics() - move the actor according to our settings
    public void applyPhysics (float dt) {
        
        //apply acceleration
        velocityVec.add(accelerationVec.x * dt, accelerationVec.y * dt);
        
        float speed = getSpeed();
        
        //decrease speed (decelerate) when we are not accelerating
        if (accelerationVec.len() == 0)
            speed -= deceleration * dt;
            
        //keep speed within set bounds
        speed = MathUtils.clamp(speed, 0, maxSpeed);
        
        //update the velocity
        setSpeed(speed);
        
        //apply velocity to move our actor
        moveBy(velocityVec.x * dt, velocityVec.y * dt);
                
        //reset acceleration
        accelerationVec.set(0,0);
    }
        
    
    //Polygon methods
    
    //setBoundaryRectangle() - by default, use a rectangle 
    public void setBoundaryRectangle() {
        float w = getWidth();
        float h = getHeight();
        float[] vertices = {0,0, w,0, w,h, 0,h};
        boundaryPolygon = new Polygon(vertices);
    }
    
    //setBoundaryPolygon() - create a boundary polygon according to given
    //   number of sides
    //  Start with defining an ellipse inscribed within the rectangle, and
    //   divide into the n segments to serve as the vertices of our polygon
    public void setBoundaryPolygon(int numSides) {
        //get the width and height to use for our ellipse
        float w = getWidth();
        float h = getHeight();
        
        //initialize our array of vertices
        float[] vertices = new float[2 * numSides];
        
        //use a for loop to fill in our array, using the formula for
        //  an ellipse
        for (int i = 0; i < numSides; i++) {
            float angle = i * (6.28f / numSides);
            
            //calculate x-coordinate
            vertices[2*i] = w/2 * MathUtils.cos(angle) + w/2;
            
            //calculate y-coordinate
            vertices[2*i + 1] = h/2 * MathUtils.sin(angle) + h/2;
        }
        
        boundaryPolygon = new Polygon(vertices);
    }
    
    //getBoundaryPolygon() - align polygon with out actor and return it
    public Polygon getBoundaryPolygon() {
        boundaryPolygon.setPosition(getX(), getY());
        boundaryPolygon.setOrigin(getOriginX(), getOriginY());
        boundaryPolygon.setRotation(getRotation());
        boundaryPolygon.setScale(getScaleX(), getScaleY());
        
        return boundaryPolygon;
    }
        
        
    //overlaps() - tells us if this BaseActor overlaps the other BaseActor
    //  Use 2-tier approach:  Test rectangles first (easy to do), then
    //    test polygons only if the rectangles do intersect
    public boolean overlaps(BaseActor other) {
        Polygon poly1 = this.getBoundaryPolygon();
        Polygon poly2 = other.getBoundaryPolygon();
        
        //initially test the rectangles for performance
        if ( !poly1.getBoundingRectangle().overlaps(poly2.getBoundingRectangle()) )
            return false;
            
        //if we are here, then the rectangles do overlap, so use the Intersector
        return Intersector.overlapConvexPolygons(poly1, poly2);
    }
        
    //Centering utility methods
    public void centerAtPosition(float x, float y)
    {
        setPosition(x - getWidth()/2, y - getHeight()/2);
    }
    
    public void centerAtActor(BaseActor other) 
    {
        centerAtPosition(other.getX() + other.getWidth()/2, 
                            other.getY() + other.getHeight()/2);
    }
    
    //setOpacity() - use for fading effects
    public void setOpacity(float opacity) {
        this.getColor().a = opacity;
    }
        
    //solid object methods
    
    //preventOverlap() - use a MinimumTranslationVector to offset our actor should
    //  it overlap with a solid object
    public Vector2 preventOverlap(BaseActor other) {
        Polygon poly1 = this.getBoundaryPolygon();
        Polygon poly2 = other.getBoundaryPolygon();
        
        //initially test Rectangles for performance reasons
        if (!poly1.getBoundingRectangle().overlaps(poly2.getBoundingRectangle()))
            return null;  //no overlap, so no vector needed to return
            
        //potential overlap, so initialize mtv and invoke Intersector
        MinimumTranslationVector mtv = new MinimumTranslationVector();
        boolean polygonOverlap = Intersector.overlapConvexPolygons(
                                                        poly1, poly2, mtv);
                                                        
        //if no overlap, no worries
        if (!polygonOverlap)
            return null;
            
        //we have overlap, so move our actor and return the mtv normal vector
        this.moveBy( mtv.normal.x * mtv.depth, mtv.normal.y * mtv.depth);
        
        //return the vector, in case we need it
        return mtv.normal;
    }
    
    //Static helper methods for ArrayList functionality
    //getList() - return a list of all actors belonging to the className's class
    //   on the given stage
    public static ArrayList<BaseActor> getList(Stage stage, String className){
        ArrayList<BaseActor> list = new ArrayList<BaseActor>();
        
        //try to get the Class from the className
        Class theClass = null;
        try {
            theClass = Class.forName(className);
        } catch(Exception error) {
            error.printStackTrace();
        }
        
        //use a for-each loop to get each actor from the stage, and if the actor
        //  is a member of our Class, add it to our new list
        for (Actor a : stage.getActors() ) {
            if ( theClass.isInstance(a) )
                list.add( (BaseActor)a );
        }
        
        return list;
    }
    
    //count - return the # of actors on stage belonging to class name
    public static int count(Stage stage, String className) {
        return getList(stage, className).size();
    }
    
    //world boundary utility methods
    
    //setWorldBounds() - width and height version
    public static void setWorldBounds(float width, float height) {
        worldBounds = new Rectangle(0,0, width,height);
    }
    
    //setWorldBounds() - use the base actor's dimensions as our world dimensions
    public static void setWorldBounds(BaseActor ba) {
        setWorldBounds(ba.getWidth(), ba.getHeight());
    }
    
    //boundToWorld() - ensure this base actor is kept within worldBounds
    public void boundToWorld() {
        //check left edge
        if (getX() < 0)
            setX(0);
        
        //check right edge
        if (getX() + getWidth() > worldBounds.width)
            setX(worldBounds.width - getWidth());
            
        //check bottom edge
        if (getY() < 0)
            setY(0);
            
        //check top edge
        if (getY() + getHeight() > worldBounds.height)
            setY(worldBounds.height - getHeight());
    }
    
    //Camera utility method
    //alignCamera() - adjust viewport if our actor is on edge of screen
    //   to prevent areas outside of game world to be visible
    public void alignCamera() {
        Camera cam = this.getStage().getCamera();
        Viewport v = this.getStage().getViewport();
        
        //first center camera on this actor
        cam.position.set(this.getX() + this.getOriginX(), 
                    this.getY() + this.getOriginY(), 0);
                    
        //bound the camera to the layout
        cam.position.x = MathUtils.clamp( cam.position.x, cam.viewportWidth/2,
                worldBounds.width - cam.viewportWidth/2 );
        cam.position.y = MathUtils.clamp( cam.position.y, cam.viewportHeight/2,
                worldBounds.height - cam.viewportHeight/2 );
                
        cam.update();
    }
}









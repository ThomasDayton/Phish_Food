
/**
 * Whirlpool effect -- extends BaseActor
 * Animation stored in a spritesheet
 */
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Whirlpool extends BaseActor
{
    // constructor - loading animation from spritesheet
    public Whirlpool(float x, float y, Stage s) {
        super (x, y, s);        // invoke super class constructore
        
        //sprite sheet is 2 by 5, duration of 0.1 seconds, no loop
        loadAnimationFromSheet("assets/whirlpool.png", 2, 5, 0.1f, false);
    }
    
    //act() - override to cleanup and remove object when finished
    public void act(float dt) {
        super.act(dt);
        
        if (isAnimationFinished()) 
            this.remove();
    }
}

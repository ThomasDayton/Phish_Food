
/**
 * BaseScreen - parent abstract class implementing Screen interface
 *   To be used by future game projects to create new screens for the game
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.Screen;

public abstract class BaseScreen implements Screen
{
    //declare properties
    protected Stage mainStage;      //expect our Stage to be inherited by games
    protected Stage uiStage;        //secondary stage for UI elements
    
    //constructor for our BaseScreen
    public BaseScreen() {
        mainStage = new Stage();
        uiStage = new Stage();
        initialize();
    }
    
    //initialize() -- template to be filled by future classes
    public abstract void initialize();
    
    //render() -- define common code for all Games; rely on update() method that
    //  will be defined by future classes to fill in gaps
    public void render(float dt) {
        //have actors on Stage act
        //float dt = Gdx.graphics.getDeltaTime();  //used to determine elpased time
        
        //Call act() to have actors update themselves
        mainStage.act(dt);
        uiStage.act(dt);
              
        //call update() to run specialized update code
        update(dt);
        
        //draw graphics
        
        //clear the screen
        Gdx.gl.glClearColor(0,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        //draw the stage
        mainStage.draw();
        uiStage.draw();
    }
    
    //template for update() class to be filled in by future games
    public abstract void update(float dt);
    
    
    // empty definitions for methods required by Screen interface
    
    public void resize(int width, int height) {}
    
    public void pause() {}

    public void resume() {}
    
    public void dispose() {}
    
    public void show() {}
    
    public void hide() {}
}

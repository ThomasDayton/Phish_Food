
/**
 * Fish class definition -- extends BaseActor
 *   Animation imported from separate files
 */
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

public class Fish extends BaseActor
{
    private boolean destroyed;
    
    //constructor - create turtle and add to the stage
    public Fish(float x, float y, Stage s) {
        
        super(x, y, s);     // invoke super class constructor
        
        //load animation frames from separate files
        //String[] filenames = 
        //    {"assets/fish.png"};
        
        //we want our Fish animation to loop with a frame duration of 0.1seconds
        loadTexture("assets/fish.png");
        
        setAcceleration(400);
        setMaxSpeed(100);
        setDeceleration(50);
        
        setBoundaryPolygon(8);  //use 8-sided bounding polygon
        
        destroyed = false;
    } 
    
    //act() - override the method to register input keys and
    //     apply physics to move the turtle 
    public void act(float dt) {
        super.act(dt);      // call super class act() method
        
        //read input key and tell turtle to accelerate at the appropriate angle
        if (Gdx.input.isKeyPressed(Keys.LEFT))
            accelerateAtAngle(180);     // left = 180 degree
        if (Gdx.input.isKeyPressed(Keys.RIGHT))
            accelerateAtAngle(0);       // right = 0 degrees
        if (Gdx.input.isKeyPressed(Keys.UP))
            accelerateAtAngle(90);      // up = 90 degrees
        if (Gdx.input.isKeyPressed(Keys.DOWN))
            accelerateAtAngle(270);     // down = 270 degrees
            
        //call applyPhysics method to move turtle
        applyPhysics(dt);
        
        //pause animation if turtle is not moving
        //setAnimationPaused( !isMoving() );
        
        //make sure Fish is facing direction it is moving
        if (getSpeed() > 0)
            setRotation( getMotionAngle() );
            
        //make sure turtle is in bounds
        boundToWorld();
        
        //align camera to our turtle
        if (!destroyed)
            alignCamera();
    }
        
    public boolean isDestroyed() {
        return destroyed;
    }
    
    //collect() - tell Starfish what to do once it is collected
    public void destroy() {
        destroyed = true;
        //clearActions(); //stop rotation
        
        addAction(Actions.fadeOut(1));  //fade out over 1 second
        addAction(Actions.after(Actions.removeActor())); //remove after fadeout done
    }    
}

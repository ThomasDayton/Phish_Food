
/**
 * BaseGame - abstract parent class to be used by future projects
 *    Stores a reference to BaseGame object for screens to reference 
 *      and allows to set the active screen
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import com.badlogic.gdx.Game;

public abstract class BaseGame extends Game 
{
    private static BaseGame game;
    
    public BaseGame() {
        game = this;
    }
    
    public static void setActiveScreen(BaseScreen s) {
        game.setScreen(s);
    }
}


/**
 * Rock object -- Treated as a solid object
 */
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Rock extends BaseActor
{
    public Rock(float x, float y, Stage s) {
        super(x, y, s);     // invoke super class constructor
        
        loadTexture("assets/rock.png");
        setBoundaryPolygon(8);
    }
    
}

/**
 * LevelScreen - the main game level screen for our Starfish Collector game
 */
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

public class LevelScreen extends BaseScreen
{
    private Fish fish;
    private boolean win;
    private boolean lose;

    //initialize() - required by abstract class GameBeta -- set up game elements
    public void initialize() {
        BaseActor ocean = new BaseActor(0, 0, mainStage);
        ocean.loadTexture("assets/water-border.jpg");
        ocean.setSize(2400, 1800);

        //use ocean image to act as boundary of world
        BaseActor.setWorldBounds(ocean);  

        for(int i=0; i < 1800; i+=64){
            if ((i > 300 && i < 550) || (i > 1000 && i < 1200)){
                //do nothing, leave space for Email
            } else {
                new Rock(300,i, mainStage);
            }
        }

        for(int i=0; i < 1800; i+=64){
            if ((i > 150 && i < 390) || (i > 700 && i < 1050)){
                //do nothing, leave space for Email
            } else {
                new Rock(1000,i, mainStage);
            }
        }

        for(int i=0; i < 1800; i+=64){
            if ((i > 450 && i < 700) || (i > 1300 && i < 1550)){
                //do nothing, leave space for Email
            } else {
                new Rock(1700,i, mainStage);
            }
        }

        //Create some starfish
        new Starfish(200,300, mainStage, 0);
        new Starfish(800,705, mainStage, 1);
        new Starfish(1600,450, mainStage, 2);
        //new Starfish(200,250, mainStage);

        //Create some phishing emails
        //new PhishingEmail(300, 1200, mainStage, 0);
        new PhishingEmail(200, 1000, mainStage, 1);
        new PhishingEmail(800, 155, mainStage, 2);
        new PhishingEmail(1700, 1305, mainStage, 3);
        //new PhishingEmail(200, 1150, mainStage, 4);

        //add the turtle at position (20, 20)
        fish = new Fish(20, 20, mainStage);

        //create some rocks 
        //new Rock(200,150, mainStage);
        //new Rock(100,300, mainStage);
        //new Rock(300,350, mainStage);
        //new Rock(450,200, mainStage);

        //initialize our game state win variable to false
        win = false;
        lose = false;

    }

    //update() - required by abstract class GameBeta -- punt and return to it
    public void update(float dt) {
        //turtle.preventOverlap(rock);  //make sure turtle is not overlapping rock
        //make sure our turtle does not overlap ANY Rock
        for (BaseActor rockActor : BaseActor.getList(mainStage, "Rock") )
            fish.preventOverlap(rockActor);

        //Use for-each to check each Starfish to see if it was collected
        for (BaseActor starfishActor : BaseActor.getList(mainStage, "Starfish") ) {

            //cast as a Starfish
            Starfish starfish = (Starfish)starfishActor;

            //If turtle overlaps the starfish, THEN
            if (fish.overlaps(starfish) && !starfish.isCollected()) {
                //   collect the starfish
                starfish.collect();

                //   Spawn a whirlpool on the Starfish
                Whirlpool whirl = new Whirlpool(0,0, mainStage);
                whirl.centerAtActor(starfish);
                whirl.setOpacity(0.25f);
            }
        }

        for (BaseActor phishingActor : BaseActor.getList(mainStage, "PhishingEmail") ) {

            //cast as a Starfish
            PhishingEmail phish = (PhishingEmail)phishingActor;

            //If turtle overlaps the starfish, THEN
            if (fish.overlaps(phish) && !fish.isDestroyed() && !win) {
                //   collect the starfish
                fish.destroy();

                //   Spawn a whirlpool on the Starfish
                Whirlpool whirl = new Whirlpool(0,0, mainStage);
                whirl.centerAtActor(fish);
                whirl.setOpacity(0.25f);
            }
        }

        //collected all the starfish, check the win condition
        if ( BaseActor.count( mainStage, "Starfish") == 0 && !win) {

            win = true; 
            //   Fade in the Win Message
            BaseActor youWinMessage = new BaseActor(0,0, uiStage);
            youWinMessage.loadTexture("assets/you-win.png");
            youWinMessage.centerAtPosition(400,300);
            youWinMessage.setOpacity(0);                 // start invisible
            youWinMessage.addAction( Actions.delay(1));  // wait 1 second
            youWinMessage.addAction( Actions.after( Actions.fadeIn(1)));  //fade in

            BaseActor restartMessage = new BaseActor(0,0, uiStage);
            restartMessage.loadTexture("assets/restart-instructions.png");
            restartMessage.centerAtPosition(400,200);
            restartMessage.setOpacity(0);
            restartMessage.addAction( Actions.delay(1));
            restartMessage.addAction( Actions.after( Actions.fadeIn(1)));
        }

        if (BaseActor.count(mainStage, "Fish") == 0 ){
            BaseActor youLoseMessage = new BaseActor(0,0, uiStage);
            youLoseMessage.loadTexture("assets/lose-message.png");
            youLoseMessage.centerAtPosition(400,300);
            youLoseMessage.setOpacity(0);
            youLoseMessage.addAction( Actions.delay(1));
            youLoseMessage.addAction( Actions.after( Actions.fadeIn(1)));

            BaseActor restartMessage = new BaseActor(0,0, uiStage);
            restartMessage.loadTexture("assets/restart-instructions.png");
            restartMessage.centerAtPosition(400,200);
            restartMessage.setOpacity(0);
            restartMessage.addAction( Actions.delay(1));
            restartMessage.addAction( Actions.after( Actions.fadeIn(1)));
        }

        if ((BaseActor.count( mainStage, "Fish") == 0 || win) && Gdx.input.isKeyPressed(Keys.D)) {
            StarfishGame.setActiveScreen(new MenuScreen());
        }
    }
}


/**
 * MenuScreen - start menu screen for Starfish Collector game
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;

public class MenuScreen extends BaseScreen
{
    // no properties needed
    
    //initialize() - how to set up our menu screen
    public void initialize() {
        //first the ocean background
        BaseActor ocean = new BaseActor(0,0, mainStage);
        ocean.loadTexture("assets/water.jpg");
        ocean.setSize(800, 600);
        
        //next load the title logo
        BaseActor title = new BaseActor(0,0, mainStage);
        title.loadTexture("assets/phish-food.png");
        title.centerAtPosition(400,500);
        //title.moveBy(0, 100);
        
        //finally load the start instructions
        BaseActor firstInstructions = new BaseActor(0,0, mainStage);
        firstInstructions.loadTexture("assets/instructions-1.png");
        firstInstructions.centerAtPosition(400,400);
        //firstInstructions.moveBy(0, -200);
        
        //finally load the start instructions
        BaseActor secondInstructions = new BaseActor(0,0, mainStage);
        secondInstructions.loadTexture("assets/instructions-2.png");
        secondInstructions.centerAtPosition(400,300);
        //secondInstructions.moveBy(0, -100);
        
        //finally load the start instructions
        BaseActor start = new BaseActor(0,0, mainStage);
        start.loadTexture("assets/message-start.png");
        start.centerAtPosition(400,200);
        //start.moveBy(0, -160);
        
        BaseActor tips = new BaseActor(0,0, mainStage);
        tips.loadTexture("assets/message-tips.png");
        tips.centerAtPosition(400,100);
        
    }
    
    //update() - listen for 'S' key input and load LevelScreen when entered
    public void update(float dt) {
        if (Gdx.input.isKeyPressed(Keys.S))
            StarfishGame.setActiveScreen( new LevelScreen() );
        if (Gdx.input.isKeyPressed(Keys.A))
            StarfishGame.setActiveScreen( new TipsScreen() );
    }
}

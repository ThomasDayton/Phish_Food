
/**
 * PhishingEmail object -- Treated as a solid object
 */
import com.badlogic.gdx.scenes.scene2d.Stage;

public class PhishingEmail extends BaseActor
{
    public PhishingEmail(float x, float y, Stage s, int spriteNum) {
        super(x, y, s);     // invoke super class constructor
        
        String spriteArray[] = new String[5];
        spriteArray[0] = "assets/PhishingEmail1.png";
        spriteArray[1] = "assets/PhishingEmail2.png";
        spriteArray[2] = "assets/PhishingEmail3.png";
        spriteArray[3] = "assets/PhishingEmail4.png";
        spriteArray[4] = "assets/PhishingEmail5.png";
        
        loadTexture(spriteArray[spriteNum]);
        setBoundaryPolygon(8);
    }
    
}

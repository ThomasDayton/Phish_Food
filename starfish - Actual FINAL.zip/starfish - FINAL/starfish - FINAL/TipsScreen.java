
/**
 * TipsScreen - start menu screen for Starfish Collector game
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;

public class TipsScreen extends BaseScreen
{
    // no properties needed
    
    //initialize() - how to set up our menu screen
    public void initialize() {
        //first the ocean background
        BaseActor ocean = new BaseActor(0,0, mainStage);
        ocean.loadTexture("assets/water.jpg");
        ocean.setSize(800, 600);
        
        //next load the title logo
        BaseActor title = new BaseActor(0,0, mainStage);
        title.loadTexture("assets/phishing-instructions-title.png");
        title.centerAtPosition(400,525);
        //title.moveBy(0, 100);
        
        //finally load the start instructions
        BaseActor firstTip = new BaseActor(0,0, mainStage);
        firstTip.loadTexture("assets/phishing-instructions-1.png");
        firstTip.centerAtPosition(400,420);
        //firstInstructions.moveBy(0, -200);
        
        //finally load the start instructions
        BaseActor secondTip = new BaseActor(0,0, mainStage);
        secondTip.loadTexture("assets/phishing-instructions-2.png");
        secondTip.centerAtPosition(400,350);
        //secondInstructions.moveBy(0, -100);
        
        BaseActor thirdTip = new BaseActor(0,0, mainStage);
        thirdTip.loadTexture("assets/phishing-instructions-3.png");
        thirdTip.centerAtPosition(400,270);
        
        BaseActor fourthTip = new BaseActor(0,0, mainStage);
        fourthTip.loadTexture("assets/phishing-instructions-4.png");
        fourthTip.centerAtPosition(400,200);
        
        BaseActor start = new BaseActor(0,0, mainStage);
        start.loadTexture("assets/message-start.png");
        start.centerAtPosition(400,100);
        
        //finally load the start instructions
        //BaseActor start = new BaseActor(0,0, mainStage);
        //start.loadTexture("assets/message-start.png");
        //start.centerAtPosition(400,300);
        //start.moveBy(0, -200);
        
    }
    
    //update() - listen for 'S' key input and load LevelScreen when entered
    public void update(float dt) {
        if (Gdx.input.isKeyPressed(Keys.S))
            StarfishGame.setActiveScreen( new LevelScreen() );
    }
}


/**
 * Starfish object - extends BaseActor
 * Uses a single, static image; add value-based animation to rotate
 */
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

public class Starfish extends BaseActor
{
    private boolean collected;
    
    //constructor - use single image version of load
    public Starfish(float x, float y, Stage s) {
        super(x, y, s);     // invoke super class constructor
        
        //use loadTexture
        loadTexture("assets/starfish.png");
        
        //create and add a spinning Action
        Action spin = Actions.rotateBy(30, 1);
        this.addAction(Actions.forever(spin));
        
        setBoundaryPolygon(8);  // use 8-sided polygon for our Starfish
        
        collected = false;
    }
    
    //isCollected() 
    public boolean isCollected() {
        return collected;
    }
    
    //collect() - tell Starfish what to do once it is collected
    public void collect() {
        collected = true;
        clearActions(); //stop rotation
        
        addAction(Actions.fadeOut(1));  //fade out over 1 second
        addAction(Actions.after(Actions.removeActor())); //remove after fadeout done
    }
    
}

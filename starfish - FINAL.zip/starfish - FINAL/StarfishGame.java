
/**
 * StarfishGame - extension of BaseGame class to initialize our game object
 */
public class StarfishGame extends BaseGame
{
    public void create() {
        setActiveScreen( new MenuScreen() );
    }
}
